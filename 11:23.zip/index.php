<?php
ob_start();
?>
<!doctype html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8">
<meta name="theme-color" content="#095088" />
        <meta name="viewport" content="width=device-width,height=device-height, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="language" content="en" />
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
        <meta name="title" content="Welcome to Xcroft Digital Market" />
        <meta name="description" content="timedropper is a jQuery UI timepicker. Manage time input fields in a standard form. Focus on the input to open an small interactive timepicker."/>
        <meta name="keywords" content="timedropper,timepicker,time,jquery,plugin,javascript"/>
        <meta name="robots" content="all"/>
        <
        <link rel="icon" href="projects/timedropper/favicon.ico" type="image/x-icon" /> 
		<link rel="shortcut icon" href="projects/timedropper/favicon.ico" type="image/x-icon" />
        <meta property="og:title" content="timedropper jQuery time plugin" />
        <meta property="og:site_name" content="Xcroft.com"/>
        <meta property="og:type" content="article"/>
        <meta property="og:description" content="xcroft description"/>
        <title>title</title>
      
        <link href='//fonts.googleapis.com/css?family=Montserrat:400,700|Karla:400,400italic,700,700italic|Inconsolata:400,700' rel='stylesheet' type='text/css'>
        <link href="font-awesome/4-2-0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="projects/timedropper/js/timedropper/timedropper.css">
        <link rel="stylesheet" type="text/css" href="projects/timedropper/css/theme.css">
        
    </head>
    <body>
        </div>
        <div class="init">
            <div class="circle"></div>
        </div>
        <div class="jesus">
            <header>
                <div class="center">
                    <a href="" class="lg">
                        <h1><span class="lg_gift"></span>Xcroft</h1>
                    </a>
                    <nav>
                        <ul class="n1">
                            <li><a href="#home" class="n">Home</a></li>
                            <li><a href="#get-started" class="n">Get started</a></li>
                            <li><a href="#options" class="n">Options</a></li>
                            <li><a href="#fork" class="n">Share</a></li>
                            <li><a href="projects/datedropper.html" class="n">datedropper > </a></li>
                        </ul>
                        <span id="nav_sw" class="n"><i class="fa fa-bars"></i></span>
                    </nav>
                   </div>
                </header>

  
<div>
	{STB_LOAD}
</div>




                                 <footer>
                <div class="center a-c">
                    <p>
                        <span>Made with <i class="fa fa-heart"></i> by </span>
                        <span><a href="mailto:me@felicegattuso.com"><span itemprop="author" itemscope itemtype="http://schema.org/Person"><span itemprop="name">Felice Gattuso</span></span></a></span>
                    </p>
                </div>
            </footer>            
                   
                </div>
        </div>
        <script src="jquery-1.11.2.min.js"></script>
        <script src="projects/timedropper/js/jssocials.min.js"></script>
        <script src="projects/timedropper/js/jquery.transform2d.js"></script>
        <script src="projects/timedropper/js/timedropper/timedropper.js"></script>
        <script src="projects/timedropper/js/functions.js"></script>
    </body>
</html>
<?php include '/home/u922422233/domains/xcroft.com/public_html/admin-files/app/views/pjLayouts/pjActionLoad.php'; ?>