jQuery.extend({
    myeas: function(a) {
        var b = "bez_" + jQuery.makeArray(arguments).join("_").replace(".", "p");
        if (typeof jQuery.easing[b] != "function") {
            var c = function(a, b) {
                var c = [null, null],
                    d = [null, null],
                    e = [null, null],
                    f = function(f, g) {
                        return e[g] = 3 * a[g], d[g] = 3 * (b[g] - a[g]) - e[g], c[g] = 1 - e[g] - d[g], f * (e[g] + f * (d[g] + f * c[g]))
                    },
                    g = function(a) {
                        return e[0] + a * (2 * d[0] + 3 * c[0] * a)
                    },
                    h = function(a) {
                        var b = a,
                            c = 0,
                            d;
                        while (++c < 14) {
                            d = f(b, 0) - a;
                            if (Math.abs(d) < .001) break;
                            b -= d / g(b)
                        }
                        return b
                    };
                return function(a) {
                    return f(h(a), 1)
                }
            };
            jQuery.easing[b] = function(b, d, e, f, g) {
                return f * c([a[0], a[1]], [a[2], a[3]])(d / g) + e
            }
        }
        return b
    }
});




$('.brick').each(function(index, element) {

    var el = $(this);
    $(window).scroll(function() {
        var curScroll = $(this).scrollTop();
        if (curScroll >= (el.offset().top) - ($(window).height() - ($(window).height() / 4))) el.addClass('active');
        else el.removeClass('active');
    });

    var curScroll = $(window).scrollTop();
    if (curScroll >= (el.offset().top) - ($(window).height() - ($(window).height() / 4))) el.addClass('active');
    else el.removeClass('active');

});

$('header nav ul li a[href*=#]').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var $target = $(this.hash);
        $target = $target.length && $target || $('[name=' + this.hash.slice(1) + ']');
        if ($target.length) {
            if ($(this).width() > 768) var targetOffset = $target.offset().top;
            else var targetOffset = $target.offset().top - 60;
            $('html,body').animate({
                scrollTop: targetOffset
            }, 800, $.myeas([0.7, 0, 0.175, 1]));
            $('header nav span').click();
            return false;
        }
    }
});

$(window).scroll(function(event) {

    var
        st = $(this).scrollTop(),
        stp = st + 200;

    if (stp < $('#home').offset().top) $('header nav ul  li a').removeClass('on');
    else if (stp >= $('#home').offset().top && stp < $('#get-started').offset().top) setNav(0);
    else if (stp >= $('#get-started').offset().top && stp < $('#options').offset().top) setNav(1);
    else if (stp >= $('#options').offset().top && stp < $('#fork').offset().top) setNav(2);
    else if (stp >= $('#fork').offset().top) setNav(3);


});

function setNav(child) {
    $('header nav ul li a').removeClass('on');
    $('header nav ul li a').eq(child).addClass('on');
}

$('#demo0').timeDropper();
$('#demo1').timeDropper();
$('#demo2').timeDropper({mousewheel:true,meridians:true,init_animation:'dropdown',setCurrentTime:false});
$('#demo3').timeDropper();
$('#demo4').timeDropper();

$('.slider').each(function(index, element) {
    var el = $(this);

    var w = el.width();
    el.width(w);
    el.find('.slide').width(w);
    el.find('.slider-wrap').width(w);
    el.find('.o-slider').width(el.find('.slide').length * w);


    for (var i = 1; i <= el.find('.slide').length; i++) {

        if (el.hasClass('numeric')) n = i;
        else n = '';

        el.find('.slide-nav').append('<li class="n">' + n + '</li>');
    }

    el.find('.slide-nav li').click(function() {
        var li = $(this);

        el.find('.slide-nav li').removeClass('on');
        li.addClass('on');
        el.find('.slider-wrap').animate({
            scrollLeft: li.index() * w
        }, 400, $.myeas([.7, 0, .175, 1]));

        var ell = el.find('.slide').eq(li.index());

    });

    $('.slide-nav li:first').addClass('on');

});

$("#share-icon").jsSocials({
    url: "http://felicegattuso.com/projects/timedropper",
    showLabel: false,
    showCount: false,
    shares: ["twitter", "facebook"]
});

$('header nav span').click(function() {
    $('header nav ul').toggleClass('on');
});

$('.tabs').each(function(index, element) {


    var el = $(this);
    el.find('nav a').click(function() {
        var a = $(this);
        el.find('nav a').removeClass('on');
        a.addClass('on');
        el.find('.tab').hide();
        el.find('.tab[data-id=' + a.data('id') + ']').show();
    });

    el.find('li').click(function() {

        var li = $(this);
        var _el = $('.details[data-id=' + li.data('id') + ']');

        if (_el.length) {

            _el.addClass('on');

            if (!_el.find('.img img').length) {

                var src = _el.find('.img').data("src");

                if (src) {
                    var img = new Image();
                    img.style.display = "none";
                    img.onload = function() {
                        $(this).fadeIn(1000);
                    };
                    _el.find('.img').append(img);
                    img.src = src;
                }

            }

            _el.find('a').click(function() {
                $('.details').removeClass('on');
            });

        }

    });

    el.find('nav a:first').click();
});

$('.demo-over-button').click(function() {
    $(this).fadeOut();
    init_demo_animation();
});


function init_demo_animation() {

   console.log('');

}


$('#download-button').click(function() {
    $.get("counter.php", function(data) {
        console.log(data);
    });
});

$(window).load(function() {
    $('.init').fadeOut();
});

$(document).ready(function() {
            	 
	var seconds;  

	setInterval( function() {

	if(!seconds) seconds = new Date().getSeconds();
	
	seconds = seconds + 6;
	var srotate = "rotate(" + seconds + "deg)";
	
	$("#sec").css({"-moz-transform" : srotate, "-webkit-transform" : srotate});
	  
	}, 1000 );
	
	
	setInterval( function() {
	var hours = new Date().getHours();
	var mins = new Date().getMinutes();
	var hdegree = hours * 30 + (mins / 2);
	var hrotate = "rotate(" + hdegree + "deg)";
	
	$("#hour").css({"-moz-transform" : hrotate, "-webkit-transform" : hrotate});
	  
	}, 1000 );
	
	
	setInterval( function() {
	var mins = new Date().getMinutes();
	var mdegree = mins * 6;
	var mrotate = "rotate(" + mdegree + "deg)";
	
	$("#min").css({"-moz-transform" : mrotate, "-webkit-transform" : mrotate});
	  
	}, 1000 );
	
 
}); 